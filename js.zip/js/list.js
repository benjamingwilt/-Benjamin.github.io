/**
 * Created by xy on 2018/12/26.
 */
$(function(){
    $("#treetable").treetable({ expandable: true });
})